<!DOCTYPE html>
<html>
<head>
	<title>E-Complaint KPTM</title>
	<link rel="stylesheet" href="css/MainPage.css">
</head>
<body>
	<h1 align="center">Welcome to KPTM E-Complaint</h1>
	<p align="center"><a href="ChooseBranch.php">Submit a complaint</a></p>
	<p align="center"><a href="">View existing complaint</a></p>
	<p align="center"><a href="TestViewAll.php">Go to Administration Panel</a></p>
</body>
</html>