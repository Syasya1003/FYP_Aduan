<!DOCTYPE html>
<html>
<head>
	<title>File Upload Limit</title>
</head>
<body>
	<ul>
		<li>Maximum number of attachments: 1</li>
		<li>Maximum size: 2 MB</li>
		<li>You may upload files ending with: <br> .gif, .jpg, .png, .zip, .rar, .csv, .doc, .docx, .xls, .xlsx, .txt, .pdf </li>
	</ul>
</body>
</html>